module.exports = {
  tokens: "TOKEN_BOT",  // Ubah Jadi Token Bot Mu !!!
  owner: "ID_OWNER", // Ubah Jadi Id Mu !!!
  port: "1466", // Ubah Jadi Port Panel Mu !!!
  ipvps: "167.172.64.240" // Ubah Jadi Ip Vps Mu !!!
};